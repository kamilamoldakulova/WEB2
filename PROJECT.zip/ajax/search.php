<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Searching</title>
    <style>
        body{
            font-family:Arial, Helvetica, sans-serif; 
            background: #2F4F4F;
            height: 900px;
        }
        *{ 
            margin:0;padding:0; 
        }
        #container {
            margin: 0 auto; 
            width: 600px;
        }
        p{
            color: antiquewhite;
            font-size: 20px;
            padding-top: 10px;
            margin-top: 10px;
        }
       
  
        #flash {
            margin-top:20px; 
            text-align:left; 
            color: black;
        }
        #searchresults { 
            text-align:left;
            margin-top:20px; 
            display:none; 
            font-family:Arial, Helvetica, sans-serif; 
            
            font-size:30px; color:#000;
        }
        .word {
            font-weight:bold;
            font-size: 30px;
            color:#000000; 
        }
        #search_box { 
            
            padding:4px;
            border:solid 1px #666666;
            width:300px; 
            height:30px; 
            font-size:18px;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
        }
        .search_button { 
            border:#000000 solid 1px;
            padding: 6px; 
            color:#000; 
            font-weight:bold;
            font-size:16px;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px; 
        }
        .found {
            font-weight: bold; 
            font-style: italic; color: #ff0000;
            font-size: 30px;
        }
 
    </style>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
    <script type="text/javascript">

    $(function() {

        $(".search_button").click(function() {
             
            var searchString    = $("#search_box").val();
             
            var data            = 'search='+ searchString;

             
            if(searchString) {
                 
                $.ajax({
                    type: "POST",
                    url: "do_search.php",
                    data: data,
                    beforeSend: function(html) {  
                        $("#results").html('');
                        $("#searchresults").show();
                        $(".word").html(searchString);
                   },
                   success: function(html){  
                        $("#results").show();
                        $("#results").append(html);
                  }
                });
            }
            return false;
        });
    });
    </script>

    </head>
    <body>
        <div id="container">
            <div style="margin:20px auto; text-align: center;">
                <form method="post" action="do_search.php">
                    Enter word<br/>
                    <input type="text" name="search" id="search_box" class='search_box' autofocus/>
                    <input type="submit" value="Search" class="search_button" /><br />
                </form>
            </div>
            <div>
                <div id="searchresults">Search results for <span class="word"></span></div>
                <p id="results">
                </p>
            </div>
        </div>
    </body>
</html>
