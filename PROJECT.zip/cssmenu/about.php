<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
   body{
      margin: 0;
      padding: 0;
      background-color:#2F4F4F;
   }
   #container1 {
     /*относительное позиционирование*/
   margin: 0 auto; /*автоматически обнуляемые отступы */
    }
  #banner {
       
      width: 960px;
      height: 250px;
      margin-top: 100px;
      margin-left: 180px;
      background: url(k1.jpg) no-repeat;
      border-radius: 20px;
    }
   .center{
      width: 960px;
       padding-bottom: 1450px;
      margin-top: 5px;
       background: black;
      border-radius: 20px;
      height: 500px;
      margin-left: 180px;

   }
   #e{
  width: 100%;
  margin-top: 20px;
  height: 150px;
  background: black;
 }
 #w{
  color: white;
  font-family: arial;
  font-size: 15px;
  float: right;
  margin-right: 550px;
  margin-top: 120px;
   
 }
   #cssmenu {
    margin: 20px;
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 65px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 40px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
    .center img{
      margin-left: 230px;
      padding-top: 30px;
    }
    .center h1{
      margin-left: 255px;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      font-size: 45px;
      color: white;
    }
    .center pre{
       
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      font-size: 17px;
      color: white;
      margin-left: 100px;
    }
     
    
   </style>
</head>
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>
 </div>
 <div id="banner"></div>
 <div class="center">
    <img src="theo3.jpg">
    <h1>THEO HUTCHCRAFT</h1>
    <pre>
      Theo David Hutchcraft (born 30 August 1986) is an English singer and songwriter, 
            best known as the lead singer
            of the electronic duo Hurts.
      ABOUT
            Vocalist and songwriter known for his work with a synthopop duo called Hurts. 
            His albums with the group include 
            Exile and Happiness.
      BEFORE FAME
            He befriended future Hurts bandmate Adam Anderson in 2005 after their mutual friends 
            became involved in a nightclub
            altercation.
      TRIVIA
            His debut album, Happiness, sold more than a million copies and 
            shot to a top ten position in a dozen countries' 
            music charts.
      FAMILY LIFE
            He dated pinup model Dita Von Teese.
      ASSOCIATED WITH
            He collaborated with pop star Kylie Minogue on the song "Devotion."
    </pre>
    <img src="adam.jpg">
    <h1> ADAM ANDERSON</h1>
    <pre>
      Adam  (born 14 May 1984) musician of famous British duo Hurts,where he 
            plays on keyboard and guitar and composes music.
      ABOUT
            Professional monster truck driver who performed for the United States Hot Rod 
            Association Monster Jam circuit in the
            truck Grave Digger, The Legend.
      BEFORE FAME
            His first truck, Taz, was named after the Looney Tunes character Tasmanian Devil.
      TRIVIA
            He has won multiple events at the Monster Jam World Finals championships.
      FAMILY LIFE
            His father is a monster truck pioneer named Dennis Anderson.
      ASSOCIATED WITH
            He is a professional monster truck driver like Tom Meents.
         
    </pre>
 </div>
 <div id="e">
      <h1 id="w">About | Help | Privacy Policy | Terms of Use</h1>
      <script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#0c0808" data-options="medium,round,line,horizontal,nocounter,theme=02" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
  </div>
   </div>
</body>
<html>

