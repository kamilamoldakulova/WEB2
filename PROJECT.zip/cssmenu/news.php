<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
     
   <title>HURTS</title>
   <style type="text/css">
   body{
      margin: 0;
      padding: 0;
      background-color: black;
   }
   a{
    text-decoration: none;
    color: white;
   }
   a:hover{
    text-decoration: underline;
    color: gray;
   }
   #container1 {
     /*относительное позиционирование*/
   margin: 0 auto; /*автоматически обнуляемые отступы */
    }
   
   .center{
      width: 960px;
      padding-top: 205px;
       padding-bottom: 20px;
      margin-top: 110px;
       background: white;
      border-radius: 20px;
       
      margin-left: 180px;

   }
   #cssmenu {
     
     
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 60px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 30px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
     #i{
      margin-left: 20px;
      margin-top: -150px;
     }
     #p{
      margin-left: 20px;
      margin-top: 10px;
     }
     #e{
      width: 100%
      margin-top:20px;
      background: #1C1C1C;
      height: 200px;
     
     }
     #e1{
  width: 100%;
  margin-top: 20px;
  height: 150px;
  background: black;
 }
     #icons{
    margin-top:20px;
  }
  #w{
  color: white;
  font-family: arial;
  font-size: 15px;
  float: right;
  margin-right: 550px;
  margin-top: 120px;
   
 }
   </style>
    
    
</head>
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='news.php'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>
 </div>
 <div class="center">
 <div>
   <img src="r.jpg" id="i">
   <pre style="font-size:35px;float:right;margin-left:5px;margin-top:-400px;color:red;background-color:white;border:1px solid white;"><b>  
  Hurts announce 
   UK tour dates 
    for 2016</b></pre>
    <pre style="font-size:20px;background-color:white;float:right;margin-top:-200px;border:1px solid white;">
    The duo release 
    third album 'Surrender' 
    on October 9<b></b></pre>
<pre style="background-color:white;font-size:20px;border:1px solid white;"> Hurts have announced a string of tour dates for 2016.</pre>
<pre style="background-color:white;font-size:20px;border:1px solid white;"> 
 The tour will support the duo’s third album 'Surrender',
 due for release on October 9.</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 Taking place throughout February and March 2016, the 24-date tour will be their 
 biggest to date. Hurts start the tour on February 11 at Glasgow’s O2 Academy, 
 before taking in Manchester Academy and London’s Brixton Academy on February 
 12 and 13 respectively.</pre>
 <img src="s.jpg" id="p">
 <pre style="background-color:white;font-size:20px;border:1px solid white;">
 The pair will then play a series of European shows, taking in Amsterdam, Prague,
 Moscow, Berlin and more. Tickets for the tour go on pre-sale on Wednesday,
 September 16 and general sale on Friday, September 18.</pre> 

<pre style="background-color:white;font-size:20px; border:1px solid white;">
 The electronic pop duo's forthcoming LP, 'Surrender', will be released on 
 October 9.It follows their 2013 album 'Exile' and 2010 debut 'Happiness'.</pre> 

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 The duo have continued their work with Swedish producer Jonas Quant. The new album 
 has also had input from Ariel Rechtshaid as well as producer Stuart Price 
 (Madonna, The Killers).</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 Having already released lead track Some Kind Of Heaven during May,
 the pair recently revealed 'Rolling Stone' and 'Lights'.</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 Watch 'Lights' below:</pre>
 <iframe style="margin-top:20px;margin-left:20px;" width="640" height="380" src="https://www.youtube.com/embed/N03wDhoXU-g" frameborder="0" allowfullscreen></iframe>
 <img src="a.jpg" style="margin-top:20px;margin-left:20px;">
 <pre style="background-color:white;font-size:29px;color:red;border:1px solid white;"><b>
  New song is taken from the Ariel Rechtshaid-produced 
  ‘Surrender’ LP.</b></pre>
 <pre style="background-color:white;font-size:20px;border:1px solid white;">
 Hurts deliver intimacy like it’s an instinct, and on their new ‘Slow’ track,
 the duo take steamed-up pop to another level.</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 The latest take from their Ariel Rechtshaid-produced album ‘Surrender’ 
 (Jonas Quant and Stuart Price are also involved) merges glitchy, earth-shaking 
 production with boldly delivered balladry. It’s dramatic to an extreme,
 Theo Hutchcraft and Adam Anderson placing regret and fear in the middle 
 of a lover’s song.</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
 Everything’s ominous, from the way they declare: “I just wanna love you / I just 
 wanna hold you close / What you’re doing here is murder / When you whip your 
 body slow.” No prizes for guessing what the song’s about, but these lusty 
 longings are in good hands - Hurts know what they’re doing, spinning something 
 futuristic out of new tools.
</pre>

<pre style="background-color:white;font-size:20px;border:1px solid white;">
‘Slow’ is premiering below on DIY. ‘Surrender’ is due out 9th October</pre>
<iframe style="margin-top:20px;margin-left:20px;border:1px solid white;" width="640" height="380" src="https://www.youtube.com/embed/xQ4xihxBZeA" frameborder="0" allowfullscreen></iframe>
 </div>
  
   
  </div>
   <div id="e1">
      <h1 id="w">About | Help | Privacy Policy | Terms of Use</h1>
      <script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#0c0808" data-options="medium,round,line,horizontal,nocounter,theme=02" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
   </div>

</body>
<html>

