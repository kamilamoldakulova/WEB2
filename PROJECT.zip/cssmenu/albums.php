<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
   body{
      margin: 0;
      padding: 0;
      background-color:black;
   }
   a{
    text-decoration: none;
    color: lightgray;
   }
   a:hover{
    text-decoration: underline;
    color: gray;
   }
   #container1 {
     /*относительное позиционирование*/
   margin: 0 auto; /*автоматически обнуляемые отступы */
    }
  #banner {
       
      width: 810px;
      height: 350px;
      margin-top: -170px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
   .center{
      width: 960px;
      padding-top: 205px;
       padding-bottom: 220px;
      margin-top: 110px;
       background: black;
      border-radius: 20px;
       
      margin-left: 180px;

   }
   #cssmenu {
     
     
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 60px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 30px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
    .surrender{
      margin-left: 50px;
      margin-top: 23px;  
    } 
    .centers{
      margin-top: -280px;
      margin-left: 440px;
      color: lightgray;
       font-family: arial;
      font-size: 30px;
    }
    .centerf{
      margin-top: 0px;
      margin-left: 440px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    .centerss{
      margin-top: -300px;
      margin-left: 505px;
      color: lightgray;
       font-family: arial;
      font-size: 30px;
    }
    .centerff{
      margin-top: 0px;
      margin-left: 505px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    #banner1{
       
      width: 810px;
      height: 350px;
      margin-top: 20px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
    .exile{
      margin-left: 120px;
      margin-top: -325px;
      float: left;

       }
       #banner2{
       
      width: 810px;
      height: 350px;

      margin-top: 235px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
    #happy{
      margin-left: 50px;
      margin-top: 25px;
    }
    .h1{
      margin-top: -280px;
      margin-left: 435px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    .h2{
      margin-top: 0px;
      margin-left: 435px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    #banner3{
      width: 810px;
      height: 350px;

      margin-top: 25px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
    #blind{
      margin-left: 120px;
      margin-top: -325px;
       float: left;
    }
    .d{
       
      margin-top: -300px;
      margin-left: 505px;
      color: lightgray;
       font-family: arial;
      font-size: 30px;
    
    }
    .centerfff{
      margin-top: 0px;
      margin-left: 505px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    #banner4{
      width: 810px;
      height: 350px;

      margin-top: 240px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
    #the{
      margin-left: 120px;
      margin-top: -325px;
       float: left;
        
    }
    #g{
      margin-top: 0px;
      margin-left: 505px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
    #m{
      margin-top: -300px;
      margin-left: 505px;
      color: lightgray;
       font-family: arial;
      font-size: 30px;
    }
   </style>
    
    
</head>
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>
 </div>
 <div class="center">
 <div id="banner">
     <img src="al1.jpg" class="surrender">
     <h1 class="centers"><a href="audio.php">Surrender Deluxe</a></h1>
     <h2 class="centerf">2015</h2>
 </div>
  
 <div id="banner1"></div>
 <img  class="exile" src="exile.jpg">
 <h1 class="centerss"><a href="#">Exile</a></h1>
 <h2 class="centerff">2013</h2>
 <div id="banner2">
   <img src="happy.jpg" id="happy">
   <h1 class="h1"><a href="#" >Happiness</a></h1>
   <h2 class="h2">2010</h2>
 </div>
 <div id="banner3"></div>
 <img src="blind.jpg" id="blind">
 <h1 class="d"><a href="#">Blind EP</a></h1>
 <h2 class="centerfff">2013</h2>
 <div id="banner4"></div>
 <img src="belle.jpg" id="the">
 <h1 id="m"><a href="#">The Belle Vue EP</a></h1>
 <h2 id="g">2010</h2>
  </div>
   
  </div>

</body>
<html>

