<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
    
   body {
    background-color: #2F4F4F;
   
  background-size: cover;
  margin: 0 auto;
}

 
   #container1 {
     /*относительное позиционирование*/
   margin: 0 auto; /*автоматически обнуляемые отступы */
    }
    #e{
  width: 100%;
  margin-top: 20px;
  height: 150px;
  background: black;
 }
 #w{
  color: white;
  font-family: arial;
  font-size: 15px;
  float: right;
  margin-right: 550px;
  margin-top: 120px;
   
 }
  #banner {
       
      width: 960px;
      height: 250px;
      margin-top: 100px;
      margin-left: 180px;
      background: url(k1.jpg) no-repeat;
      border-radius: 20px;
    }
   .center{
      width: 960px;
       padding-bottom: 1000px;
      margin-top: 100px;
       background: black;
      border-radius: 20px;
      height: 500px;
      margin-left: 180px;

   }
   #cssmenu {
    margin: 20px;
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 65px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 40px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
    #first{
      margin-left: 20px;
      margin-top: 20px;
    }
    .center a{
      text-decoration: none;
      color: white;
    }
    .center h1 a:hover {
      color: white;
       
      text-decoration: underline;

    }
    </style> 
     
 
     
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>
 </div>
  
 <div class="center">
     <img src="MEN.jpg" id="first">
     <img src="girl.jpg" style="margin-left:80px;margin-top:20px;">
     <img src="gray.jpg" style="margin-left:80px;margin-top:20px;">
     <h1 style="margin-top:10px;margin-left:30px;color:white;font-size:18px;font-family: "Oswald";"><a href="mens.php"><span>MENS 2016 FEB-MARCH</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:370px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>GIRLS 2016 FEB-MARCH</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:710px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>GIRLS EMBROUIDERED</span></a></h1>
     <h1 style="margin-top:-10px;margin-left:40px;color:white;font-size:17px;font-family: "Oswald";">BLACK TOUR T-SHIRT</h1>
     <h1 style="margin-top:-35px;margin-left:380px;color:white;font-size:17px;font-family: "Oswald";">BLACK TOUR T-SHIRT</h1>
     <h1 style="margin-top:-35px;margin-left:770px;color:white;font-size:17px;font-family: "Oswald";">LOGO GREY</h1>
     <h1 style="margin-top:-5px;margin-left:100px;color:white;font-size:17px;font-family: "Oswald";">&#163 20.00</h1>
     <h1 style="margin-top:-35px;margin-left:440px;color:white;font-size:17px;font-family: "Oswald";">&#163 20.00</h1>
     <h1 style="margin-top:-35px;margin-left:790px;color:white;font-size:17px;font-family: "Oswald";">&#163 40.00</h1>
     <img src="grey.jpg" style="margin-top:50px;margin-left:20px;">
     <img src="POSTER1.jpg" style="margin-top:50px;margin-left:80px;">
     <img src="logo.jpg" style="margin-top:50px;margin-left:80px;">
     <h1 style="margin-top:10px;margin-left:40px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>MENS EMBROUIDERED</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:400px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>2016 TOUR POSTER</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:700px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>WHITE EMBROUIDERED</span></a></h1>
     
     <h1 style="margin-top:-10px;margin-left:75px;color:white;font-size:17px;font-family: "Oswald";">LOGO BLACK</h1>
     <h1 style="margin-top:-35px;margin-left:380px;color:white;font-size:17px;font-family: "Oswald";"></h1>

     <h1 style="margin-top:-35px;margin-left:725px;color:white;font-size:17px;font-family: "Oswald";">LOGO BLACK BEANIE</h1>
     <h1 style="margin-top:-5px;margin-left:100px;color:white;font-size:17px;font-family: "Oswald";">&#163 40.00</h1>
     <h1 style="margin-top:-35px;margin-left:440px;color:white;font-size:17px;font-family: "Oswald";">&#163 15.00</h1>
     <h1 style="margin-top:-35px;margin-left:790px;color:white;font-size:17px;font-family: "Oswald";">&#163 12.00</h1>

     <img src="led.jpg" style="margin-top:50px;margin-left:20px;">
     <img src="node.jpg" style="margin-top:50px;margin-left:80px;">
     <img src="t-shirt.jpg" style="margin-top:50px;margin-left:80px;">
     <h1 style="margin-top:10px;margin-left:60px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>LED GLOWSTICK</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:400px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>EMBOSSED LOGO</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:700px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>WHITE SURRENDER DYE</span></a></h1>
     
     <h1 style="margin-top:-10px;margin-left:75px;color:white;font-size:17px;font-family: "Oswald";"></h1>
     <h1 style="margin-top:-5px;margin-left:435px;color:white;font-size:17px;font-family: "Oswald";">NODEPAD</h1>

     <h1 style="margin-top:-35px;margin-left:760px;color:white;font-size:17px;font-family: "Oswald";">SUB T-SHIRT</h1>

     <h1 style="margin-top:-5px;margin-left:100px;color:white;font-size:17px;font-family: "Oswald";">&#163 5.00</h1>
     <h1 style="margin-top:-35px;margin-left:440px;color:white;font-size:17px;font-family: "Oswald";">&#163 20.00</h1>
     <h1 style="margin-top:-35px;margin-left:790px;color:white;font-size:17px;font-family: "Oswald";">&#163 25.00</h1>
     


     <img src="phone.jpg" style="margin-top:50px;margin-left:20px;">
     <img src="pillow.jpg" style="margin-top:50px;margin-left:80px;">
     <img src="tights.jpg" style="margin-top:50px;margin-left:80px;">
     <h1 style="margin-top:10px;margin-left:50px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>SURRENDER I PHONE</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:400px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>BLACK HURTS LOGO</span></a></h1>
     <h1 style="margin-top:-35px;margin-left:730px;color:white;font-size:18px;font-family: "Oswald";"><a href="#"><span>BLACK 100 DENIER</span></a></h1>
     
     <h1 style="margin-top:-10px;margin-left:105px;color:white;font-size:17px;font-family: "Oswald";">CASE</h1>
     <h1 style="margin-top:-30px;margin-left:425px;color:white;font-size:17px;font-family: "Oswald";">PILLOWCASE</h1>

     <h1 style="margin-top:-35px;margin-left:760px;color:white;font-size:17px;font-family: "Oswald";">HURTS TIGHTS</h1>

     <h1 style="margin-top:-10px;margin-left:100px;color:white;font-size:17px;font-family: "Oswald";">&#163 15.00</h1>
     <h1 style="margin-top:-30px;margin-left:440px;color:white;font-size:17px;font-family: "Oswald";">&#163 15.00</h1>
     <h1 style="margin-top:-35px;margin-left:790px;color:white;font-size:17px;font-family: "Oswald";">&#163 20.00</h1>

      
 </div>
 <div id="e">
      <h1 id="w">About | Help | Privacy Policy | Terms of Use</h1>
      <script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#0c0808" data-options="medium,round,line,horizontal,nocounter,theme=02" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
  </div>
   </div>
     
</body>
 
    
</html>

