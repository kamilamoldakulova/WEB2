<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
    
   body {
  background: url('video.png');
  background-size: cover;
  margin: 0 auto;
}

.bgvideo {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  z-index: -9999;
}
    
   
   .center{
      width: 960px;
       padding-bottom: 400px;
      margin-top: 100px;
       background: black;
      border-radius: 20px;
      height: 500px;
      margin-left: 180px;

   }
   #k{
    float: right;
    margin-right: 10px;
    margin-top: -199px;
   }
    
    </style> 
     
 
     
<body>
<video autoplay loop muted class="bgvideo" id="bgvideo">
   <source src="world.mp4" type="video/mp4"></source>
  </video>

 <div id="container1"> 
  
 <div class="center">
    <img src="for.jpg" style="margin-top:50px;margin-left:20px;">
    <div>
      <pre style="font-size:35px;float:right;color:white;margin-top:-500px; font-family:fantasy;"> MENS 2016 FEB-MARCH 
 BLACK TOUR T-SHIRT
      </pre>
      <pre style="font-size:40px;float:right;color:white;margin-top:-400px;margin-right:200px;font-family:fantasy;">&#163 20.00</pre>
    </div>
    <div>
      <img src="front.jpg" id="k">
      <img src="back.jpg" id="k">
    </div>
    <div style="margin-left:150px;margin-top:20px;" >
      <form action="#"> 
      <div style="margin-left:50px;margin-top:100px;"> 
      <input type="submit" value="Buy now" style="width:200px;height:100px" >
       </form> 
       </div>
   </div>
     
</body>
 
    
</html>

