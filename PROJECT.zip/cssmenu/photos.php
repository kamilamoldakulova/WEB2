<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
    
   body {
    background-color: #2F4F4F;
   
  background-size: cover;
  margin: 0 auto;
}

 
    
    #e{
  width: 100%;
  margin-top: 20px;
  height: 150px;
  background: black;
 }
 #w{
  color: white;
  font-family: arial;
  font-size: 15px;
  float: right;
  margin-right: 550px;
  margin-top: 120px;
   
 }
   
   .center{
      width: 960px;
       padding-bottom: 1000px;
      margin-top: 100px;
       background: black;
      border-radius: 20px;
      height: 3300px;
      margin-left: 180px;

   }
   #cssmenu {
    margin: 20px;
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 65px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 40px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
     
    .for{
      height: 350px;
      width: 800px;
      padding-left: 100px;
      padding-top: 20px;
    }
    .center a{
      text-decoration: none;
      color: white;
    }
    .center h1 a:hover {
      color: white;
       
      text-decoration: underline;

    }
    #for{
      color: white;
      font-size: 25px;
      text-align:justify;
    }
    .to{
      width: 120px;
      height: 315px;
      float: right;
    }
    </style> 
     
 
     
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>
 </div>
  
 <div class="center">
     <div class="for">
     <iframe width="560" height="315" src="https://www.youtube.com/embed/Pt1kc_FniKM" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Somebody die for</p>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/05J79Y8zQTw" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">All  I Want for Christmas Is Year's Day</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/L8MRqQHD_kM" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Evelyn</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/pGoy9YhJ8iE" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Blood, Tears and Gold</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/v4i6W1DfWbA" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Confide In Me</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/c3BvW56tjB0" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Sunday</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/HrAclaz5GvA" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Micarcle</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/6CvuyaKmLnw" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Illuminated</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/UVTNiyHVLTs" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Devotion</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/MIgaWx48U8A" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Blind</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/1TB1x67Do5U" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Wonderful Life</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/1nP3XB7hrFo" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Stay</pre>
     </div>
     <iframe width="560" height="315" src="https://www.youtube.com/embed/SzE3kNUWA9s" frameborder="5" allowfullscreen></iframe>
     <div class="to">
     <p id="for">Some Kind of Heaven</pre>
     </div>
     </div>

 </div>
 <div id="e">
      <h1 id="w">About | Help | Privacy Policy | Terms of Use</h1>
      <script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#0c0808" data-options="medium,round,line,horizontal,nocounter,theme=02" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
  </div>
   </div>
     
</body>
 
    
</html>

