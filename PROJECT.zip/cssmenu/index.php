<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <script type="text/javascript" src="tabcontent.js"></script>
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 
   <title>HURTS</title>
   <style type="text/css">
   body{
      margin: 0 auto;
      padding: 0;
      background-color:#2F4F4F;
   }
   #container1 {
      
   margin: 0 auto;  

    }
  #banner {
       
      width: 960px;
      height: 250px;
      margin-top: 100px;
      margin-left: 180px;
      background: url(k1.jpg) no-repeat;
      border-radius: 20px;
    }
   #center{
      width: 900px;
       padding-top: 120px;

      color: #FF82AB;
      border-radius: 50px;
      height: 500px;
      margin-left: 200px;

   }
   #cssmenu {
    margin: 20px;
    margin-left: 180px;
     margin-top: -75px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 70px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 20px;
      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 40px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
    .container{

    margin-top: 5px;
    width:960px;
    background-color: black;  
    border-radius: 20px;
    margin-left: 180px;
    }

   .carousel-inner > .item > img,
   .carousel-inner > .item > a > img {
       
      margin: auto;
      padding-bottom: 20px;
   }
 #e{
  width: 100%;
  margin-top: 5px;
  height: 150px;
  background: black;
 }
 #w{
  color: white;
  font-family: arial;
  font-size: 15px;
  float: right;
  margin-right: 550px;
  margin-top: 120px;
   
 }
 #o{
    width: 960px;
      margin-top: 5px;  
      background-color: black;
      border-radius: 20px;
      height: 1050px;
      margin-left: 180px;
 }
    
   </style>
</head>
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch1.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>
   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>

</ul>
 </div>
 <div id="banner"></div>
 <div id="o">
    <h1 style="color:white;font-size:20px;float:right;margin-right:550px;margin-top:40px;">There are multiple artists named "Hurts"</h1>
    <img src="band.jpg" style="float:right;margin-top:-40px;margin-right:20px;">
    <pre style="font-size:20px;color:white; float:left;background-color:black;border:1px solid black; font-family:arial;">
   Manchester, UK electro-pop duo 
   Theo Hutchcraft and Adam Anderson.
   Formed in 2009, elegant and 
   enigmatic HURTS have their sharp 
   suits,slick hair and stark visuals.
   Theo and Adam  present a striking 
   contrast to the glow-in-the-dark 
   pop stars who have run amok across
   the charts of late. Looking like 
   they would rather be on the cover 
   of Vogue Hommes than NME or Smash
   Hits, the pair resemble Tears For 
   Fears as shot by Anton Corbijn… 
  <a href=""> read more</a></pre>
  <iframe style="margin-top:20px;margin-right:75px;margin-left:20px;" width="500" height="500" src="https://www.youtube.com/embed/8235uYaUfoA" frameborder="0" allowfullscreen></iframe>
  <h1 style="float:right; margin-right:30px;margin-top:110px; color:white">Surrender Tour 2016</h1>
  <h1 style="float:right; margin-right:30px;margin-top:-370px; color:white">Live in Moscow</h1>
   
 </div>
  <div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
     
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
    </ol>

     
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="sm.jpg">
      </div>

      <div class="item">
        <img src="h1.jpg"  >
      </div>
    
      <div class="item">
        <img src="h2.jpg" >
      </div>

      <div class="item">
        <img src="h3.jpg"  >
      </div>
      <div class="item">
        <img src="h.jpg" >
      </div>
      <div class="item">
        <img src="36_Hurts_by.jpg" >
      </div>
       
    </div>

     
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  </div>
  <div id="e">
      <h1 id="w">About | Help | Privacy Policy | Terms of Use</h1>
      <script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="#0c0808" data-options="medium,round,line,horizontal,nocounter,theme=02" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print"></div>
  </div>
  </div>
   
</body>
<html>
