<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
     
   <title>HURTS</title>
   <style type="text/css">
   body{
      margin: 0;
      padding: 0;
      background-color:#2F4F4F;
   }
    
   #container1 {
     /*относительное позиционирование*/
   margin: 0 auto; /*автоматически обнуляемые отступы */
    }
  #banner {
       
      width: 810px;
      height: 1680px;
      margin-top: -170px;
      margin-left: 70px;
       background: white;
      border-radius: 20px;
    }
   .center{
      width: 960px;
      padding-top: 205px;
       padding-bottom: 70px;
      margin-top: 110px;
       background: black;
      border-radius: 20px;
       
      margin-left: 180px;

   }
   #cssmenu {
     
     
    margin-left: 180px;
     margin-top: -80px;
    list-style-type: none;
    width: 960px;
    position: fixed;
    display: block;
    height: 60px;
    font-size: 14px;
    font-weight: bold;
     
    border-radius: 20px; 
      background: black;
      font-family: "Trebuchet MS", Helvetica, Arial, Verdana, sans-serif;
      border-bottom: 5px solid #8B8682;
      border-top: 5px solid #8B8682;
    }
    #cssmenu li {
      display: block;
      float: left;
      margin: 0px;
      margin-top: 10px;

      
    }
    #cssmenu li a {
       
      float: left;
      color: #999999;
      text-decoration:none;
      font-weight: bold;
      padding: 0px 50px 0 30px;
      height: 30px;
    }
    #cssmenu li a:hover {
      color: #FFFFFF;
      background: black;
       
    }
    .surrender{
      margin-left: 50px;
      margin-top: 23px;  
    } 
    .centers{
      margin-top: -280px;
      margin-left: 440px;
      color: lightgray;
       font-family: arial;
      font-size: 30px;
    }
    .centerf{
      margin-top: 0px;
      margin-left: 440px;
      color: lightgray;
      font-family: arial;
      font-size: 30px;
    }
     
     
   </style>
    
    
</head>
<body>
 <div id="container1">
<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>HOME</span></a></li>
   <li><a href='albums.php'>ALBUMS</a></li>
   <li><a href='../blog1'><span>NEWS</span></a></li>
   <li><a href='photos.php'><span>VIDEOS</span></a></li>
   <li><a href='merch.php'><span>MERCH</span></a></li>
   <li><a href='about.php'><span>ABOUT</span></a></li>

   <li><a href='phpform/intropage.php'><span>LOGIN</span></a></li>
</ul>S
 </div>
 <div class="center">
 <div id="banner">
     <img src="al1.jpg" class="surrender">
     <h1 style="float:right;font-size:30px;margin-top:30px;margin-right:300px;">Album</h1>
     <h1 style="float:right;font-size:30px;margin-top:-250px;margin-right:160px;">Surrender Deluxe</h1>

     <iframe frameborder="0" style="border:none;width:700px;height:100px;margin-top:10px;float:right;margin-right:60px;" width="700" height="100"  src="https://music.yandex.kz/iframe/#track/25373332/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373332'>Surrender</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/23959178/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/23959178'>Some Kind of Heaven</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373333/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373333'>Why</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373334/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373334'>Nothing Will Be Bigger Than Us</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/24391284/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/24391284'>Rolling Stone</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/24744376/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/24744376'>Lights</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25041782/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25041782'>Slow</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373335/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373335'>Kaleidoscope</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373336/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373336'>Wings</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373337/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373337'>Wish</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373338/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373338'>Perfect Timing</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373339/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373339'>Weight of the World</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe>
     <iframe frameborder="0" style="border:none;width:700px;height:100px;float:right;margin-right:60px;" width="700" height="100" src="https://music.yandex.kz/iframe/#track/25373340/2990574">Слушайте <a href='https://music.yandex.kz/album/2990574/track/25373340'>Policewoman</a> — <a href='https://music.yandex.kz/artist/168654'>Hurts</a> на Яндекс.Музыке</iframe> 
     </div>

 </div>
  
  </div>

</body>
<html>

