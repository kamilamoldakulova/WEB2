<!Doctype html>
<html>
<head>
<meta charset="utf-8">
    <title>Adding</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" >
</head>
<body style="background:#2F4F4F;width:100%;height:100%;">
    <div class="container">
        <h1 style="color:black;">MY BLOGS ABOUT HURTS</h1>
        <div border="">
        <form method="post" action="index.php?action=<?=$_GET['action']?>&id=<?=$_GET['id']?>">
              
                <h3 style="color:black;">Title</h3>
                <input type="text" name="title" value="<?=$article['title']?>"   style="height:30px; width:1000px;" autofocus required><br> 
             
             
                <h3 style="color:black;">Date</h3>
                <input type="date" name="date"  value="<?=$article['date']?>"  style="height:30px; width:1000px;"  required> <br> 
             
             
                <h3 style="color:black;">Article</h3>
                <textarea  style="height:500px; width:1000px;" name="content" required><?=$article['content']?></textarea> <br> 
             
                <input type="submit" value="Save" class="btn"> 
            </form>
        </div>  
        <footer>
            <p>Hurts<br>Copyright&copy;2016</p>
        </footer>
        </div>
    </body>
</html>