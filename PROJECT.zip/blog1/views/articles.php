<!Doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
    <title>HURTS</title>
</head>
<body style="background-color: #2F4F4F;" >
     
    <div class="container">
        <h1 style="color: black;  font-size:50px;">MY BLOGS ABOUT HURTS</h1>
        <a href="admin" style="color: aqua; font-size:20px;">Panel Admin</a>
        <p style="color: aqua;"><a href="../ajax/search.php" style="color: aqua; font-size:20px;">Do you want to Search? </a></p> 

        <div>
            <?php foreach($articles as $a): ?>
            <div class="article">
                <h3><a href="article.php?id=<?=$a['id']?>"><?=$a['title']?></a></h3>
                <em>Published: <?=$a['date']?></em>
                <p><?=articles_intro($a['content'])?></p>
            </div>
            <?php endforeach ?>
            
        </div>
        <footer>
            <p>Hurts<br> Copyright &copy; 2016</p>
        </footer>
    </div>
</body>
</html>