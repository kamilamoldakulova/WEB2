<!Doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >
    <title>HURTS</title>
</head>
<body style="background:#2F4F4F;">
    <div class="container">
        <h1 style="color:black;" >MY BLOGS ABOUT HURTS</h1>
        <a href="index.php?action=add" style="color:aqua;">Add Article</a>
        <div>
         <table  class="admin-table" border="2" >
            <tr>
                    <th style="color:black;font-size:20px;">Date</th>
                    <th style="color:black;font-size:20px;">Title</th>
                    <th></th>
                    <th></th>

            </tr>
            
            <?php foreach($articles as $a): ?>

                        
            <tr>
                <td style="color:black;font-size:20px;"><?=$a['date']?></td>
                
                <td style="color:black;font-size:20px;"><?=$a['title']?></td>
                
                <td style="font-size:20px;"><a style="color:blueviolet;" href="index.php?action=edit&id=<?=$a['id']?>">Edit</a></td>
                
                <td style="font-size:20px;"><a href="index.php?action=delete&id=<?=$a['id']?>">Delete</a>
                </td>
            </tr>
            <?php endforeach ?>

        </table>

             
            
        </div>
        <footer>
            <p style="color:black;">Hurts<br> Copyright &copy; 2016</p>
        </footer>
    </div>
</body>
</html>